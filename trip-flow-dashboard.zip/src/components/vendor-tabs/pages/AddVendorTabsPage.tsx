'use client';
import VendorVehicleTabsRoot from '../VendorVehicleTabsRoot';
export default function AddVendorTabsPage(){
  return <VendorVehicleTabsRoot mode="add"/>;
}
